package com.quickchat;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

public class QuickChat {
    private static boolean loggedIn = false;
    private static int totalMessagesToSend;
    private static int messagesSentCount = 0;
    private static List<Message> allMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("=====================================");
        System.out.println("   Welcome to QuickChat   ");
        System.out.println("=====================================");
        
        if (!login(scanner)) {
            System.out.println("Login failed. Exiting application.");
            return;
        }
        
        System.out.print("How many messages do you wish to send? ");
        totalMessagesToSend = scanner.nextInt();
        scanner.nextLine();
        
        int option;
        do {
            System.out.println("\n===== MAIN MENU =====");
            System.out.println("Option 1) Send Messages");
            System.out.println("Option 2) Show recently sent messages");
            System.out.println("Option 3) Quit");
            System.out.print("Enter your choice: ");
            option = scanner.nextInt();
            scanner.nextLine();
            
            switch (option) {
                case 1:
                    sendMessageFlow(scanner);
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    System.out.println("Exiting QuickChat. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (option != 3);
        
        scanner.close();
    }
    
    private static boolean login(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        
        if (username.equals("user") && password.equals("pass")) {
            loggedIn = true;
            System.out.println("Login successful!\n");
            return true;
        } else {
            System.out.println("Invalid credentials.");
            return false;
        }
    }
    
    private static void sendMessageFlow(Scanner scanner) {
        if (messagesSentCount >= totalMessagesToSend) {
            System.out.println("You have reached your limit of " + totalMessagesToSend + " messages.");
            displayTotalMessages();
            return;
        }
        
        Message msg = new Message();
        
        System.out.print("Enter recipient number (with international code, e.g., +27718693002): ");
        String recipient = scanner.nextLine();
        String validationResult = msg.checkRecipientCell(recipient);
        if (!validationResult.equals("Cell phone number successfully captured.")) {
            System.out.println(validationResult);
            return;
        }
        msg.setRecipient(recipient);
        
        System.out.print("Enter your message (max 250 characters): ");
        String messageText = scanner.nextLine();
        if (messageText.length() > 250) {
            int excess = messageText.length() - 250;
            System.out.println("Message exceeds 250 characters by " + excess + "; please reduce the size.");
            return;
        }
        System.out.println("Message ready to send.");
        msg.setMessageText(messageText);
        
        msg.generateMessageId();
        msg.setMessageNumber(messagesSentCount + 1);
        msg.createMessageHash();
        
        String sendResult = msg.sendMessageOption(scanner);
        System.out.println(sendResult);
        
        if (sendResult.equals("Message successfully sent.")) {
            messagesSentCount++;
            allMessages.add(msg);
            msg.printMessageDetails();
            msg.storeMessageToJson();
        } else if (sendResult.equals("Message successfully stored.")) {
            storedMessages.add(msg);
            msg.storeMessageToJson();
        } else if (sendResult.equals("Press 0 to delete the message.")) {
            System.out.println("Message disregarded and deleted.");
        }
        
        if (messagesSentCount >= totalMessagesToSend) {
            displayTotalMessages();
        }
    }
    
    private static void displayTotalMessages() {
        System.out.println("\n===== SUMMARY =====");
        System.out.println("Total number of messages sent: " + messagesSentCount);
        System.out.println("\nAll sent messages:");
        for (Message m : allMessages) {
            System.out.println("- " + m.getMessageText() + " (to: " + m.getRecipient() + ")");
            System.out.println("  ID: " + m.getMessageId() + " | Hash: " + m.getMessageHash());
        }
    }
}

class Message {
    private String messageId;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;
    private static int totalMessagesCreated = 0;
    
    public boolean checkMessageID() {
        return messageId != null && messageId.length() <= 10;
    }
    
    public String checkRecipientCell(String cellNumber) {
        if (cellNumber.matches("^\\+[0-9]{10,13}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }
    
    public String createMessageHash() {
        String firstTwoDigits = messageId.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        lastWord = lastWord.replaceAll("[^A-Z]", "");
        messageHash = firstTwoDigits + ":" + messageNumber + ":" + firstWord + lastWord;
        return messageHash;
    }
    
    public String sendMessageOption(Scanner scanner) {
        System.out.println("\nChoose an option:");
        System.out.println("1. Send Message");
        System.out.println("2. Store Message to send later");
        System.out.println("3. Disregard Message");
        System.out.print("Enter choice: ");
        
        int choice = scanner.nextInt();
        scanner.nextLine();
        
        switch (choice) {
            case 1:
                totalMessagesCreated++;
                return "Message successfully sent.";
            case 2:
                return "Message successfully stored.";
            case 3:
                return "Press 0 to delete the message.";
            default:
                return "Invalid option. Message disregarded.";
        }
    }
    
    public String printMessages(List<Message> messages) {
        StringBuilder sb = new StringBuilder();
        for (Message m : messages) {
            sb.append(m.toString()).append("\n");
        }
        return sb.toString();
    }
    
    public int returnTotalMessages(List<Message> messages) {
        return messages.size();
    }
    
    public void storeMessageToJson() {
        try {
            JSONObject jsonMessage = new JSONObject();
            jsonMessage.put("messageId", this.messageId);
            jsonMessage.put("messageNumber", this.messageNumber);
            jsonMessage.put("recipient", this.recipient);
            jsonMessage.put("messageText", this.messageText);
            jsonMessage.put("messageHash", this.messageHash);
            jsonMessage.put("timestamp", java.time.LocalDateTime.now().toString());
            
            JSONArray messagesArray = new JSONArray();
            try (BufferedReader reader = new BufferedReader(new FileReader("messages.json"))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                if (sb.length() > 0) {
                    messagesArray = new JSONArray(sb.toString());
                }
            } catch (IOException e) {
                System.out.println("Creating new messages.json file...");
            }
            
            messagesArray.put(jsonMessage);
            
            try (FileWriter file = new FileWriter("messages.json")) {
                file.write(messagesArray.toString(4));
                System.out.println("✓ Message stored in messages.json");
            }
        } catch (IOException e) {
            System.out.println("Error storing message in JSON: " + e.getMessage());
        }
    }
    
    public void printMessageDetails() {
        System.out.println("\n===== MESSAGE SENT =====");
        System.out.println("Message ID: " + messageId);
        System.out.println("Message Hash: " + messageHash);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + messageText);
        System.out.println("=======================\n");
    }
    
    public void generateMessageId() {
        Random rand = new Random();
        long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        messageId = String.valueOf(id);
    }
    
    public String getMessageId() { return messageId; }
    public void setMessageId(String messageId) { this.messageId = messageId; }
    public int getMessageNumber() { return messageNumber; }
    public void setMessageNumber(int messageNumber) { this.messageNumber = messageNumber; }
    public String getRecipient() { return recipient; }
    public void setRecipient(String recipient) { this.recipient = recipient; }
    public String getMessageText() { return messageText; }
    public void setMessageText(String messageText) { this.messageText = messageText; }
    public String getMessageHash() { return messageHash; }
    public static int getTotalMessagesCreated() { return totalMessagesCreated; }
    
    @Override
    public String toString() {
        return "ID: " + messageId + " | Hash: " + messageHash + " | To: " + recipient + " | Msg: " + messageText;
    }
}